from django.contrib import admin
from .models import ContatoSolicitacao, ServicoReforma

@admin.register(ContatoSolicitacao)
class ContatoSolicitacaoAdmin(admin.ModelAdmin):
    list_display = ['nome', 'email', 'assunto', 'data_criacao', 'respondido']
    list_filter = ['respondido', 'data_criacao']
    search_fields = ['nome', 'email', 'assunto']
    readonly_fields = ['data_criacao']
    list_editable = ['respondido']
    
    fieldsets = (
        ('Informações do Contato', {
            'fields': ('nome', 'email', 'telefone', 'assunto')
        }),
        ('Mensagem', {
            'fields': ('mensagem',)
        }),
        ('Status', {
            'fields': ('respondido', 'data_criacao')
        })
    )

@admin.register(ServicoReforma)
class ServicoReformaAdmin(admin.ModelAdmin):
    list_display = ['nome', 'tipo', 'preco_base', 'ativo']
    list_filter = ['tipo', 'ativo']
    search_fields = ['nome', 'descricao']
    list_editable = ['ativo', 'preco_base']