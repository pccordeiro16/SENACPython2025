from django.apps import AppConfig


class ReformasappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reformasapp'
    verbose_name = 'Reformas e Manutenção'