from django.urls import path
from . import views

app_name = 'reformasapp'

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('servicos/', views.servicos, name='servicos'),
    path('quem-somos/', views.quem_somos, name='quem_somos'),
    path('contato/', views.contato, name='contato'),
]