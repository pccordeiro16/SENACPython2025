from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .forms import ContatoForm
from .models import ServicoReforma

def inicio(request):
    """Página inicial do site"""
    servicos_destaque = ServicoReforma.objects.filter(ativo=True)[:3]
    context = {
        'servicos_destaque': servicos_destaque
    }
    return render(request, 'reformasapp/inicio.html', context)

def servicos(request):
    """Página de serviços"""
    servicos_lista = ServicoReforma.objects.filter(ativo=True)
    context = {
        'servicos': servicos_lista
    }
    return render(request, 'reformasapp/servicos.html', context)

def quem_somos(request):
    """Página sobre a empresa"""
    return render(request, 'reformasapp/quem_somos.html')

def contato(request):
    """Página de contato com formulário"""
    if request.method == 'POST':
        form = ContatoForm(request.POST)
        if form.is_valid():
            # Salva a solicitação no banco
            solicitacao = form.save()
            
            # Envia email (opcional)
            try:
                send_mail(
                    subject=f'Nova solicitação: {solicitacao.assunto}',
                    message=f'''
                    Nova solicitação de contato recebida:
                    
                    Nome: {solicitacao.nome}
                    Email: {solicitacao.email}
                    Telefone: {solicitacao.telefone}
                    Assunto: {solicitacao.assunto}
                    
                    Mensagem:
                    {solicitacao.mensagem}
                    ''',
                    from_email=settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@reformas.com',
                    recipient_list=['contato@reformas.com'],  # Substitua pelo seu email
                )
            except Exception as e:
                print(f'Erro ao enviar email: {e}')
            
            messages.success(request, 'Sua mensagem foi enviada com sucesso! Entraremos em contato em breve.')
            return redirect('reformasapp:contato')
    else:
        form = ContatoForm()
    
    context = {
        'form': form
    }
    return render(request, 'reformasapp/contato.html', context)